const { version } = require('../../package.json');
const config = require('../config/config');

const swaggerDef = {
  openapi: '3.0.0',
  info: {
    title: 'express-boiler-plate API documentation',
    version,
    license: {
      name: 'MIT',
      url: 'https://github.com/madhurjya/express-boiler-plate.git',
    },
  },
  servers: [
    {
      url: `http://localhost:${config.port}/v1`,
    },
  ],
};

module.exports = swaggerDef;
